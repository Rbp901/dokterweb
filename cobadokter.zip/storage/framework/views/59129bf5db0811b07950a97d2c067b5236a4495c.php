<?php $__env->startSection('content'); ?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Guest Book</title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-12">
                <div class="card-header text-center">
                  <a>  CRUD Data Pegawai  </a>
                </div>
            <div>
            <p>Cari Data Pegawai :</p>
	        <form action="/datamurid/cari" method="GET">
		    <input type="text" name="cari" placeholder="Cari Datamurid .." value="<?php echo e(old('cari')); ?>">
		    <input type="submit" value="CARI">
	        </form>
            </div> 
                <div class="card-body">
                    <a href="/datamurid/tambah" class="btn btn-primary">Input Pegawai Baru</a>
                    <br/>
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>NIS</th>
                                <th>NAMA</th>
                                <th>KELAS</th>
                                <th>NO HP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datamurid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->id); ?></td>
                                <td><?php echo e($p->nis); ?></td>
                                <td><?php echo e($p->nama); ?></td>
                                <td><?php echo e($p->kelas); ?></td>
                                <td><?php echo e($p->nohp); ?></td>
                                <td>
                                    <a href="/datamurid/edit/<?php echo e($p->id); ?>" class="btn btn-warning">Edit</a>
                                    <a href="/datamurid/hapus/<?php echo e($p->id); ?>" class="btn btn-danger">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br/>
	Halaman : <?php echo e($datamurid->currentPage()); ?> <br/>
	Jumlah Data : <?php echo e($datamurid->total()); ?> <br/>
	Data Per Halaman : <?php echo e($datamurid->perPage()); ?> <br/>
 
 
	<?php echo e($datamurid->links()); ?>

                </div>
            </div>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/datamurid.blade.php ENDPATH**/ ?>