<html>
<head>
<title></title>
</head>
<body>
    

    <div class="links">
	<a href="home">BACK</a>
	<h1>Data Murid</h1>
	<a href="/cobaLaravel/public/latihancrud/tambah">+tambah data baru</a>
	<br/>
    <br/>

	<div class ="form-group">
	Cari data:<form action="/cobaLaravel/public/latihancrud/cari"
	method="GET">
	<input type="text" name="cari" placeholder="Cari nama Murid" value="<?php echo e(old('cari')); ?>">
	<input type="submit" value="CARI">
	</form>

<table>
<tr>
<th>Nis</th>
<th>Nama</th>
<th>Kelas</th>
<th>No.Hp</th>
</tr>
<?php $__currentLoopData = $datamurid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($p->nis); ?></td>
	<td><?php echo e($p->nama); ?></td>
	<td><?php echo e($p->kelas); ?></td>
	<td><?php echo e($p->nohp); ?></td>
	<td>
		<a href="/cobaLaravel/public/latihancrud/edit/<?php echo e($p->nis); ?>">edit</a>
		<a href="/cobaLaravel/public/latihancrud/hapus/<?php echo e($p->nis); ?>">hapus</a>
	</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/tampildata.blade.php ENDPATH**/ ?>