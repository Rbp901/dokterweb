<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color:  #eee;
                color: #F08080;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                 {
  margin-top: 100px;
  margin-bottom: 100px;
  margin-right: 150px;
  margin-left: px;
}
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                }a:link, a:visited {
  background-color: #00FFFF;
 
}

a:hover, a:active {
  background-color: #20B2AA;
}

            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: maroon;
                padding: 0 100px;
                font-size: 22px ;
                font-weight: 600;
                letter-spacing: rem;
               text-decoration: underline;

                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/login')); ?>">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">

                    <CENTER><h1>
                   ridho
                    </h1><H2></CENTER>


                </div>

               <div class="links">
                    <a href="Aboutme">CV</a>
                    <a href="contact">KONTAK KAMI</a>
                    <a href="formulir">Passing Data</a>
                    <a href="latihancrud">Buku Tamu</a>

                </div>
                <br><center>
                <h1>
                Selamat Datang Di Website Kami </h1></center>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/welcome.blade.php ENDPATH**/ ?>