<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>About Me</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #ggg;
                color: #636b6f;
                font-family: 'Nunito', times new roman;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .mang{
                position: relative;
                font-size: 25px;
                top :10vh;
                left:10vh;


            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 40px;
                font-weight: bold;
                position: relative;
                right: 10px;
                top: 60px;
                left: 40px;

            }

            .links > a {
                color: #636b6f;
                padding: 0 50px;
                font-size: 30px;
                font-weight: 600;
                letter-spacing: .4rem;
                text-decoration: none;
                text-transform: uppercase;
                position: relative;
                right: 20px;
                top: 10px;
                left: 30vh;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <p><p>
        <div class="links">
            <a href="\belajar_laravel;\public">Home</a>
                <a href="contact">Kontak Kami</a>
                <a href="formulir">Formulir</a>
                <a href="4">Blog</a>
                </div>
                <p><p>

        <div class="flex-left position-ref full-height>
            <div class="content" align="center">
                <br><br>
                <h1>ABOUT ME</h1>
                <img alt="me" src="\laravelapp\resources\views\aboutme.png"  height="500" width="450" align="center">
                </div>
            </div>
        </div>
        
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\belajar_laravel;\resources\views/Aboutme.blade.php ENDPATH**/ ?>