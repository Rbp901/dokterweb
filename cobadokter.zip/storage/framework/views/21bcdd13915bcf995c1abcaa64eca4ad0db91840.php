<?php $__env->startSection('content'); ?>



<div class="container">
                    <div class="row">
                        <div class="col-md-11">
                            <div class="four-features four-features-right-top">
                                <div class="features-img">
                                    <img src="assets/images/18.png" alt="Responsive image" class="img-responsive">
                                </div>
                                </div>
                                
                        </div>
                     
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/cv.blade.php ENDPATH**/ ?>