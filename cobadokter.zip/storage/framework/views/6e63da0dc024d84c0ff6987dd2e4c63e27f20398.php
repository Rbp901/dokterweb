<html>
<head>
	<title>CRUD PADA LARAVEL</title>
</head>
<body><center>
<h1>Data Murid</h1>
<a href="/belajar_laravel;/public/latihancrud/tambah"> + Tambah Data Baru</a>
<br>
<br>
<table border="1">

<tr>

<th>NIS</th>
<th>NAMA</th>
<th>KELAS</th>
<th>NO. HP</th>
<th>OPTION</th>

</tr>

<?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>

<td><?php echo e($p->NIS); ?></td>
<td><?php echo e($p->nama); ?></td>
<td><?php echo e($p->kelas); ?></td>
<td><?php echo e($p->nohp); ?></td>


<td>
<a href="/belajar_laravel;/public/latihancrud/edit/<?php echo e($p->NIS); ?>">Edit</a>
<a href="/belajar_laravel;/public/latihancrud/hapus/<?php echo e($p->NIS); ?>">Hapus</a>
</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\belajar_laravel;\resources\views/tampildata.blade.php ENDPATH**/ ?>