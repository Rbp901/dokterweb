<?php $__env->startSection('content'); ?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Tabel Lihat Dokter</title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-12">
                <div class="card-header text-center">
                  <p> Data Lihat Dokter  </p>
                </div>
            <div>
            <div class="card-body">
                    <a href="/dataspesialis" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
            <div>
            
            <p></p>
	        <form action="/datalihatdokter/cari" method="GET">
		    <input type="text" name="cari" placeholder="Cari Nama Dokter .." value="<?php echo e(old('cari')); ?>">
		    <input type="submit" value="CARI">
	        </form> 
            </div> 
                <div class="card-body">
                
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Kd Spesialis</th>
                                <th>Nama Dokter</th>
      
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datalihatdokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->kdspesialis); ?></td>
                                <td><?php echo e($p->namadokter); ?></td>

                                <td>
                                    <a href="/datajadwal" class="btn btn-success">Lihat Jadwal</a>
                                   
                                </td>
                            

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
      
                    <br/>


	<?php echo e($datalihatdokter->links()); ?> 


                </div>
            </div>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaDokter\resources\views/datalihatdokter.blade.php ENDPATH**/ ?>