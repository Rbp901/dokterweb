<?php $__env->startSection('content'); ?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Tabel Spesialis</title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-12">
                <div class="card-header text-center">
                  <p> Data Spesialis  </p>
                </div>
            <div>
            
            <p></p>
	        <form action="/dataspesialis/cari" method="GET">
		    <input type="text" name="cari" placeholder="Cari Spesialis .." value="<?php echo e(old('cari')); ?>">
		    <input type="submit" value="CARI">
	        </form> 
            </div> 
                <div class="card-body">
                <!--
                    <a href="/datatamu/tambah" class="btn btn-primary">Input Data Spesialis Baru</a>
                    <br/> -->
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Kd Spesialis</th>
                                <th>Spesialis</th>
      
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dataspesialis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->kdspesialis); ?></td>
                                <td><?php echo e($p->spesialis); ?></td>

                                <td>
                                    <a href="/datalihatdokter" class="btn btn-warning">Lihat Dokter</a>
                                   
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
      
                    <br/>


	<?php echo e($dataspesialis->links()); ?> 


                </div>
            </div>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaDokter\resources\views/dataspesialis.blade.php ENDPATH**/ ?>