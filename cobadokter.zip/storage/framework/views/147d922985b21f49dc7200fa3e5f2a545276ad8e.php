<div id="header" class="pt-5">
    <div class="pt-5 top">
        <div class="d-flex pl-5">
            <div class="ml-5">
                <img class="me shadow" src="assets/me.jpg" alt="" >
            </div>
           
            <div class="position-relative w-100">
                <div class="ml-5">
                <p class="name title mb-0">Ridho Bayu Prihatmoko</p>
                <span class="d-block sub-title">Software Enginering</span>

                <div class="mt-4 txt-light txt-big">
                    <div>BOGOR, INDONESIA</div>
                    <div>STUDENT OF SMKN 24 JAKARTA</div>
                    
                </div>
                </div>
                

                <div class="nav ">
                    <li class="col"><a href=""> <i class="fas fa-server pr-2"></i> ANDROID DEVELOPMENT</a></li>
                    <li class="col"><a href=""> <i class="fab fa-laravel pr-2"></i> WEB DEVELOPMENT</a></li>
                    <li class="col"><a href=""> <i class="fas fa-file-download pr-2"></i> MY RESUME</a></li>
                    <li class="col"><a href=""> <i class="fas fa-headphones-alt pr-2"></i> CONTACT ME</a></li>

                    <li class="col"><a href="cv"> <i class="fas fa-headphones-alt pr-2"></i> MY CV</a></li>
                </div>
               
            </div>
        </div>
       
    </div>
</div><?php /**PATH C:\xampp\htdocs\vinny\resources\views/client/inc/header.blade.php ENDPATH**/ ?>