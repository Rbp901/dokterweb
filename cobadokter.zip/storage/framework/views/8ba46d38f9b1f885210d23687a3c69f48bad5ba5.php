<?php $__env->startSection('content'); ?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Data Jadwal</title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-12">
                <div class="card-header text-center">
                  <p> Data Jadwal  </p>
                </div>
            <div>
            <div class="card-body">
                    <a href="/datalihatdokter" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
            <div>
            
            <p></p>
	        <form action="/datajadwal/cari" method="GET">
		    <input type="text" name="cari" placeholder="Cari Hari .." value="<?php echo e(old('cari')); ?>">
		    <input type="submit" value="CARI">
	        </form> 
            </div> 
                <div class="card-body">
                <!--
                    <a href="/datatamu/tambah" class="btn btn-primary">Input Data Spesialis Baru</a>
                    <br/> -->
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Nama Dokter</th>
                                <th>Hari</th>
                                <th>Jam Mulai</th>
                                <th>Jam Selesai</th>
      
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datajadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->namadokter); ?></td>
                                <td><?php echo e($p->hari); ?></td>
                                <td><?php echo e($p->jammulai); ?></td>
                                <td><?php echo e($p->jamselesai); ?></td>

                               

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
      
                    <br/>


	<?php echo e($datajadwal->links()); ?> 


                </div>
            </div>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaDokter\resources\views/datajadwal.blade.php ENDPATH**/ ?>