<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Data Lihat Dokter </title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-6">
                <div class="card-header text-center">
                  <a>  Data Lihat Dokter </a>
                </div>
                <div class="card-body">
                    <a href="/datalihatdokter" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
            <div>
         
	        </form>
            </div> 
                    <br/>
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>KD SPESIALIS</th>
                                <th>NAMA DOKTER</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datalihatdokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->kdspesialis); ?></td>
                                <td><?php echo e($p->namadokter); ?></td>
                        
                           
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
      
 
 
	<?php echo e($datalihatdokter->links()); ?>

                </div>
            </div>
        </div>
    </body>
</html>


<?php echo $__env->make('datalihatdokter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaDokter\resources\views/indexlihatdokter.blade.php ENDPATH**/ ?>