<!DOCTYPE html>
<html>
<head>
    <title>Form Sederhana</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>" />
</head>

<body>
    <div align="center">
        <?php if(Session::has('status')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('status')); ?></div>
            <?php endif; ?>
            <br><br>
            <h4>Form Passing Data</h4> 
            <p>Memindahkan data dari input form ke controller</p>
            <div class="col-md-3">
                <form action="/laravelapp/public/formulir/proses" method="post">
                <input type="hidden" name="_token" value="<?php echo csrf_token()?>">
                <?php echo e(csrf_field()); ?>


                    <label for="nama">Nama</label>
                    <input class="form-control" type="text" name="nama" placeholder="isi nama" />
                    
                    <label for="alamat">Alamat</label>
                    <input class="form-control" type="text" name="alamat" placeholder="isi alamat" />
                    <br><br>

                    <button class="btn btn-success btn-block" style="text-align: 
                    center;">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/Formulir.blade.php ENDPATH**/ ?>