<h1> Hallo anjing </h1>
<table>
    <tr>
        <th>NAMA DEPAN</th>
        <th>NAMA BELAKANG</th>
        <th>JENIS KELAMIN</th>
        <th>AGAMA</th>
        <th>ALAMAT</th>
</tr>
<?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td> <?php echo e($siswa->nama_depan); ?></td>
    <td> <?php echo e($siswa->nama_belakang); ?></td>
    <td> <?php echo e($siswa->jenis_kelamin); ?></td>
    <td> <?php echo e($siswa->agama); ?></td>
    <td> <?php echo e($siswa->alamat); ?></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/siswa/index.blade.php ENDPATH**/ ?>