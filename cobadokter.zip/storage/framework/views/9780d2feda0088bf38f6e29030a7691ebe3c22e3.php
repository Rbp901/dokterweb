<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>" />
</head>

<body>
 <style>
            html, body {
                background-color:  #eee;
                color: #F08080;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                 {
  margin-top: 100px;
  margin-bottom: 100px;
  margin-right: 150px;
  margin-left: px;
}
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                }a:link, a:visited {
  background-color: #00FFFF;
 
}

a:hover, a:active {
  background-color: #20B2AA;
}

            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: maroon;
                padding: 0 100px;
                font-size: 22px ;
                font-weight: 600;
                letter-spacing: rem;
               text-decoration: underline;

                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/login')); ?>">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">

                    <CENTER><h1>
                   Falah Web
                    </h1><H2></CENTER>


                </div>

               <div class="links">
                    <a href="Aboutme">CV</a>
                    <a href="contact">KONTAK KAMI</a>
                    <a href="formulir">Passing Datang</a>
                    <a href="4">BLOG</a>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 ">
            <div class="card nt-9">
                <div class="card-body">


                <h4>Contact Us</h4>
                <p>Have any question or feedback?</p>

                <?php if(Session::has('status')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('status')); ?></div>
                <?php endif; ?>

                <form action="" method="post">

                    <?php echo e(csrf_field()); ?>


                    <label for="name">Name</label>
                    <input class="form-control" type="text" name="name" placeholder="you name" />
                    
                    <label for="email">Email</label>
                    <input class="form-control" type="email" name="email" placeholder="you email address" />
                    
                    <label for="message">Message</label>
                    <textarea class="form-control" name="message" id="" placeholder="your message" cols="30" rows="10"></textarea>

                    <br><br>

                    <button class="btn btn-success btn-block">Send</button>
                <form>
            </div>
        </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\belajar_laravel;\resources\views/contact-form.blade.php ENDPATH**/ ?>