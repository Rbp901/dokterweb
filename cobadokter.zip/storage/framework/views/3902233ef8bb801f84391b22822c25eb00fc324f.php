<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Data Dokter </title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-6">
                <div class="card-header text-center">
                  <a>  CRUD Data Murid </a>
                </div>
                <div class="card-body">
                    <a href="/datadokter" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
            <div>
            <p>Cari Data Murid :</p>
	        <form action="/datadokter/cari" method="GET">
		    <input type="text" name="cari" placeholder="Cari Datadokter .." value="<?php echo e(old('cari')); ?>">
		    <input type="submit" value="CARI">
	        </form>
            </div> <!--
                <div class="card-body">
                    <a href="/datadokter/tambah" class="btn btn-primary">Input Murid Baru</a> -->
                    <br/>
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>KD DOKTER</th>
                                <th>NAMA DOKTER</th>
                                <th>KD SPESIALIS</th>
                                <th>NOMOR TELEPON</th>
                                <th>JENIS KELAMIN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datadokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->kddokter); ?></td>
                                <td><?php echo e($p->namadokter); ?></td>
                                <td><?php echo e($p->kdspesialis); ?></td>
                                <td><?php echo e($p->telepon); ?></td>
                                <td><?php echo e($p->jk); ?></td>
                           
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
      
 
 
	<?php echo e($datadokter->links()); ?>

                </div>
            </div>
        </div>
    </body>
</html>


<?php echo $__env->make('datadokter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaDokter\resources\views/index.blade.php ENDPATH**/ ?>