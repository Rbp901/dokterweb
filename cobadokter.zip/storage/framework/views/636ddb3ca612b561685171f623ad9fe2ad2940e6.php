<html>
<head> <title> Daftar  Mahasiswa </title> </head>

<tbody>
<div class="container">
    <div class="row">
        <div class="col-10">
            <h1 class="mt-3">Daftar Mahasiswa </h1>
            <table class="table">
                <thead class ="thead-dark">
                    <thead class ="thead-dark">
                    <tr>
                    <th scope="row">#</th>
                    <th scope="row">Nama</th>
                    <th scope="row">NRP</th>
                    <th scope="row">Email</th>
                    <th scope="row">Jurusan</th>
                    <th scope="row">Aksi</th>
</tr>
</thead>
<tbody>
         <tr>           
                    <th scope="row">1</th>
                    <td>Ridho Bayu P</td>
                    <td>086457836</td>
                    <td>rbayu901@gmail.com</td>
                    <td>TI</td>
<td>
                    <a href="" class="badge badge-success">edit</a>
                    <a href="" class="badge badge-danger">hapus</a>
</td>
</tr>
</tbody>



</div>
</div>
</div>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>