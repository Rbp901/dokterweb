<?php $__env->startSection('content'); ?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Daftar Dokter</title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-12">
                <div class="card-header text-center">
                  <p> Data Dokter </p>
                </div>
            <div>
            
            <p></p>
	        <form action="/datadokter/cari" method="GET">
		    <input type="text" name="cari" placeholder="Cari Nama Dokter .." value="<?php echo e(old('cari')); ?>">
		    <input type="submit" value="CARI">
	        </form> 
            </div> 
            <!--
                <div class="card-body">
                    <a href="/datadokter/tambah" class="btn btn-primary">Input Dokter Baru</a>
                    <br/> -->
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>KD DOKTER</th>
                                <th>NAMA DOKTER</th>
                                <th>KD SPESIALIS</th>
                                <th>NO TELEPON</th>
                                <th>JENIS KELAMIN</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datadokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->kddokter); ?></td>
                                <td><?php echo e($p->namadokter); ?></td>
                                <td><?php echo e($p->kdspesialis); ?></td>
                                <td><?php echo e($p->telepon); ?></td>
                                <td><?php echo e($p->jk); ?></td>
                 
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br/>
    <!--                
	Halaman : <?php echo e($datadokter->currentPage()); ?> <br/>
	Jumlah Data : <?php echo e($datadokter->total()); ?> <br/>
	Data Per Halaman : <?php echo e($datadokter->perPage()); ?> <br/>
 -->
 
	<?php echo e($datadokter->links()); ?>

                </div>
            </div>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaDokter\resources\views/datadokter.blade.php ENDPATH**/ ?>