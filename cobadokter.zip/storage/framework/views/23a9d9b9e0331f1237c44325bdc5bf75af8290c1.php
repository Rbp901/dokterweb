<?php $__env->startSection('content'); ?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title> Guest Book</title>
    </head>
   <body>
        <div class="container">
            <div class="card mt-12">
                <div class="card-header text-center">
                  <a>  CRUD Data Tamu  </a>
                </div>
            <div>
            <p>Cari Data Tamu :</p>
	        <form action="/datatamu/cari" method="GET">
		    <input type="text" name="cari" placeholder="Cari Datatamu .." value="<?php echo e(old('cari')); ?>">
		    <input type="submit" value="CARI">
	        </form>
            </div> 
                <div class="card-body">
                    <a href="/datatamu/tambah" class="btn btn-primary">Input Tamu Baru</a>
                    <br/>
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>NAMA</th>
                                <th>EMAIL</th>
                                <th>COMMENT</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datatamu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->id); ?></td>
                                <td><?php echo e($p->nama); ?></td>
                                <td><?php echo e($p->email); ?></td>
                                <td><?php echo e($p->komen); ?></td>
                     <!--           
                                <td>
                                    <a href="/datatamu/edit/<?php echo e($p->id); ?>" class="btn btn-warning">Edit</a>
                                    <a href="/datatamu/hapus/<?php echo e($p->id); ?>" class="btn btn-danger">Hapus</a>
                                </td> -->
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br/>
	Halaman : <?php echo e($datatamu->currentPage()); ?> <br/>
	Jumlah Data : <?php echo e($datatamu->total()); ?> <br/>
	Data Per Halaman : <?php echo e($datatamu->perPage()); ?> <br/>
 
 
	<?php echo e($datatamu->links()); ?>

                </div>
            </div>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/datatamu.blade.php ENDPATH**/ ?>