<?php $__env->startSection('content'); ?>
<section id="footer">
            <div class="container">
                <div class="footer-top">
                    <div class="section-heading">
                        <div class="title">
                            <div class="row">
                                <div class="col-md-12">
                                <h2>ABOUT  ME</h2>
                                </div>
                            </div>
                        </div>
                        <div class="subtitle">
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <p>
                                   I'm currently a high school student with a great interest in various forms of Technology such as Programming, Graphic Design, and IoT
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</section>
<div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="four-features four-features-left-bottom">
                                <div class="features-img">
                                    <img src="assets/images/07.jpg" alt="Responsive image" class="img-responsive">
                                </div>
                                </div>
                        </div>
                        <div class="col-md-6">
                            <div class="four-features four-features-right-bottom">
                                <img src="assets/images/08.jpg" alt="Responsive image" class="img-responsive">
                              
                            </div>
                        </div>
                    </div>
</div>




   

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/home.blade.php ENDPATH**/ ?>