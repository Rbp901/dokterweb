<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title></title>
    </head>
    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    CRUD Data - <strong>TAMBAH DATA</strong> - <a href="" target="_blank"></a>
                </div>
                <div class="card-body">
                    <a href="/datamurid" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
                    
                    <form method="post" action="/datamurid/store">
 
                        <?php echo e(csrf_field()); ?>


                       
                        <div class="form-group">
                            <label>NIS</label>
                            <input type="text" name="nis" class="form-control" placeholder="NIS datamurid ..">
 
                            <?php if($errors->has('nis')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('nis')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
                        <div class="form-group">
                            <label>NAMA</label>
                            <input type="text" name="nama" class="form-control" placeholder="Nama datamurid ..">
 
                            <?php if($errors->has('nama')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('nama')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
                        <div class="form-group">
                            <label>KELAS</label>
                            <input type="text" name="kelas" class="form-control" placeholder="Kelas datamurid ..">
 
                            <?php if($errors->has('kelas')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('kelas')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
                        <div class="form-group">
                            <label>NO HP</label>
                            <input type="text" name="nohp" class="form-control" placeholder="Nohp datamurid ..">
 
                            <?php if($errors->has('nohp')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('nohp')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
 <!--
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea name="alamat" class="form-control" placeholder="Alamat pegawai .."></textarea>
 
                             <?php if($errors->has('alamat')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('alamat')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>  -->
 
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
 
                    </form>
 
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/datamurid_tambah.blade.php ENDPATH**/ ?>