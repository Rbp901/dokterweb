@extends('layouts.frontend.master')

@section('content')
<section id="footer">
            <div class="container">
                <div class="footer-top">
                    <div class="section-heading">
                        <div class="title">
                            <div class="row">
                                <div class="col-md-12">
                                <h2>ABOUT CALL DOKTER</h2>
                                </div>
                            </div>
                        </div>
                        <div class="subtitle">
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1">
                                    <p>
                                    Layanan Kesehatan dengan berbasis Website yang digunakan untuk memudahkan masyarakat memperoleh informasi
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</section>

<!--
<div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="four-features four-features-left-bottom">
                                <div class="features-img">
                                    <img src="assets/images/07.jpg" alt="Responsive image" class="img-responsive">
                                </div>
                                </div>
                        </div>
                        <div class="col-md-6">
                            <div class="four-features four-features-right-bottom">
                                <img src="assets/images/08.jpg" alt="Responsive image" class="img-responsive">
                              
                            </div>
                        </div>
                    </div>
</div> -->
<section id="one">
            <div class="container">
                <div class="one-features">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="section-highlight">
                                <h2></h2>
                            </div>
                            <div class="section-details">
                                <p>
                       
                                </p>
                               
                            </div>
                        </div>
                        <div class="col-md-4">
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>



<section id="two">
            <div class="container">
                <div class="two-features">
                    <div class="row">
                        <div class="col-md-4">
                        <img src="assets/images/imagess.jpg" alt="Responsive image" class="img-responsive">
                        </div>
                        <div class="col-md-8">
                            <div class="section-highlight">
                                <h2>Profesional</h2>
                            </div>
                            <div class="section-details">
                                <p>
                                Layanan Kesehatan dengan berbasis Website yang digunakan untuk memudahkan masyarakat memperoleh informasi
                                </p>
                                <a href="/contact" class="btn btn-learn-more">LEARN MORE <i class="ion-ios-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>




<section id="one">
            <div class="container">
                <div class="one-features">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="section-highlight">
                                <h2>Melayani</h2>
                            </div>
                            <div class="section-details">
                                <p>
                                Layanan Kesehatan dengan berbasis Website yang digunakan untuk memudahkan masyarakat memperoleh informasi
                                </p>
                                <a href="/contact" class="btn btn-learn-more">LEARN MORE <i class="ion-ios-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <img src="assets/images/download.png" alt="Responsive image" class="img-responsive">
                        </div>
                    </div>
                </div>
            </div>
        </section>

      




   

        @stop