@extends('layouts.frontend.master')

@section('content')



<div class="container">
                    <div class="row">
                        <div class="col-md-11">
                            <div class="four-features four-features-right-top">
                                <div class="features-img">
                                    <img src="assets/images/18.png" alt="Responsive image" class="img-responsive">
                                </div>
                                </div>
                                
                        </div>
                     
</div>


@stop